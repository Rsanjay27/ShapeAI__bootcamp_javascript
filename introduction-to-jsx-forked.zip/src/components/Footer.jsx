import React from "react";

function Footer() {
  return (
    <footer>
      <p>Copyright by shape ai @ {new Date().getFullYear()}
      </p>
      </footer>
      
  );
}export default Footer;