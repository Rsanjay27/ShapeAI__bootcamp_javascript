import React from "react";
function Info() {
  return (
    <div className="note">
      <h1 className="note">Javascript and React.js</h1>
      <p className="note">A basic web dev React Js bootcamp </p>
      </div>
  );
  }
export default Info;